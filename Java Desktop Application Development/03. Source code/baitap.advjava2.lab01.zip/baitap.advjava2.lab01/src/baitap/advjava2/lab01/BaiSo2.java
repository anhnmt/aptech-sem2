/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baitap.advjava2.lab01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author minhvufc
 */
public class BaiSo2 {

    public static void main(String[] argv) throws Exception {
        updateDB();
    }

    public static void updateDB() {
        try {
            String driver = "com.mysql.jdbc.Driver";

            Class.forName(driver);
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dblab01", "root", "12345678");

            // Đối tượng lệnh truy vấn
            Statement stmt = null;
            stmt = conn.createStatement();

            // Cú pháp sql tạo bảng
            String sql = "CREATE TABLE IF NOT EXISTS `tbladmin` (\n"
                    + "  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Khóa chính',\n"
                    + "  `username` text NOT NULL COMMENT 'Tên',\n"
                    + "  `email` text NOT NULL COMMENT 'Địa chỉ email',\n"
                    + "  `password` text NOT NULL COMMENT 'Mật khẩu đăng nhập',\n"
                    + "  `note` text COMMENT 'Ghi chú',\n"
                    + "  PRIMARY KEY (`id`)\n"
                    + ") ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;";
            stmt.execute(sql); // Kích hoạt sql

            // Thêm dữ liệu vào bảng
            stmt.executeUpdate("INSERT INTO `tbladmin` (`id`, `username`, `email`, `password`, `note`) VALUES\n"
                    + "(1, 'Vũ Tuấn Minh', 'minhvt.hanoi@gmail.com', '1a544567131f33b3e6b177ef71f6b894', 'Quản trị hệ thống');");

            // Thông báo dữ liệu đã thêm
            System.out.println("1 row affected");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

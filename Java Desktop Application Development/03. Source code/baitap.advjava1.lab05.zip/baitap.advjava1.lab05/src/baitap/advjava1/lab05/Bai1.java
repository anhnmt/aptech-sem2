/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baitap.advjava1.lab05;

import java.awt.BorderLayout;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author minhvufc
 */
public class Bai1 extends JFrame {

    // Mảng 1 chiều lưu trữ tên cột
    String arrColumn[] = new String[]{"STT", "Mã SV", "Họ và tên", "Lớp", "Giới tính"};

    // Mảng 2 chiều lưu trữ danh sách sinh viên
    String arrData[][] = new String[][]{
        new String[]{"1", "BK001", "Quang Trung", "Java", "Nam"},
        new String[]{"2", "BK002", "Nguyễn Huệ", "Android", "Nữ"},
        new String[]{"3", "BK003", "Van Persie", "C#", "LES"},
        new String[]{"4", "BK004", "Ronaldo", "PHP", "Gay"},
        new String[]{"5", "BK005", "Nguyễn Công Phượng", ".NET", "Nam"},
        new String[]{"1", "BK001", "Quang Trung", "Java", "Nam"},
        new String[]{"2", "BK002", "Nguyễn Huệ", "Android", "Nữ"},
        new String[]{"3", "BK003", "Van Persie", "C#", "LES"},
        new String[]{"4", "BK004", "Ronaldo", "PHP", "Gay"},
        new String[]{"5", "BK005", "Nguyễn Công Phượng", ".NET", "Nam"},
        new String[]{"1", "BK001", "Quang Trung", "Java", "Nam"},
        new String[]{"2", "BK002", "Nguyễn Huệ", "Android", "Nữ"},
        new String[]{"3", "BK003", "Van Persie", "C#", "LES"},
        new String[]{"4", "BK004", "Ronaldo", "PHP", "Gay"},
        new String[]{"5", "BK005", "Nguyễn Công Phượng", ".NET", "Nam"}};

    public Bai1() {
        initUI();

    }

    private void initUI() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Danh sách sinh viên");
        setLayout(new BorderLayout());
        loadDSSinhVien();
    }
    JTable tblSinhVien;

    private void loadDSSinhVien() {
        tblSinhVien = new JTable(arrData, arrColumn);
        JScrollPane scroll = new JScrollPane(tblSinhVien);
        setSize(400, 250);
        getContentPane().add(scroll, BorderLayout.CENTER);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bai1 b1 = new Bai1();

        Thread thred = new Thread(new Runnable() {

            @Override
            public void run() {
                try {
                    Thread.sleep(2000);

                    b1.arrData[0] = new String[]{"99", "BK099", "Văn Quyến", "Java 1", "Nam 1"};
                    ((AbstractTableModel) b1.tblSinhVien.getModel()).fireTableCellUpdated(0, 2);
                    b1.repaint();
//                    b1.tblSinhVien = new JTable(b1.arrData, b1.arrColumn);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Bai1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        thred.start();

        b1.setLocationRelativeTo(null);
        b1.setVisible(true);
    }

}

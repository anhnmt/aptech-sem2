/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sem2.demo.i18n;

import java.awt.GridLayout;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author VTMinh
 */
public class Sem2DemoI18n {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Locale locale = Locale.CANADA_FRENCH;
        
        Locale locale = Locale.getDefault();
        System.out.println(locale.getDisplayCountry());
        ResourceBundle rb = ResourceBundle.getBundle("sem2.demo.i18n.resources.resources", locale);
//        JFrame.setDefaultLookAndFeelDecorated(true);
        
        JFrame frame = new JFrame("I18N Test");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(3, 2));
        frame.add(new JLabel(rb.getString("userName")));
        frame.add(new JTextField());
        frame.add(new JLabel(rb.getString("password")));
        frame.add(new JPasswordField());
        frame.add(new JButton(rb.getString("login")));
        
        frame.pack();
        frame.setVisible(true);
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baitap.advjava1.lab04;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author minhvufc
 */
public class SwingControlDemoJList {

    private JFrame mainFrame;
    private JLabel headerLabel;
    private JLabel statusLabel;
    private JPanel controlPanel;

    public SwingControlDemoJList() {
        prepareGUI();
    }

    public static void main(String[] args) {
        SwingControlDemoJList swingControlDemo = new SwingControlDemoJList();
        swingControlDemo.showListDemo();
    }

    private void prepareGUI() {
        mainFrame = new JFrame("Java Swing Examples");
        mainFrame.setSize(400, 400);
        mainFrame.setLayout(new GridLayout(3, 1));
        mainFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent windowEvent) {
                System.exit(0);
            }
        });
        headerLabel = new JLabel("", JLabel.CENTER);
        statusLabel = new JLabel("", JLabel.CENTER);

        statusLabel.setSize(350, 100);

        controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        mainFrame.add(headerLabel);
        mainFrame.add(controlPanel);
        mainFrame.add(statusLabel);
        mainFrame.setVisible(true);
    }

    private void showListDemo() {

        headerLabel.setText("Ví dụ về  JList");

        // Tạo model
        final DefaultListModel fruitsName = new DefaultListModel();

        fruitsName.addElement("Táo");
        fruitsName.addElement("Cam");
        fruitsName.addElement("Bưởi");
        fruitsName.addElement("Vú sữa");

        // Tạo list với tùy chọn chỉ cho phép lựa chọn 1 item / 1 lần
        final JList fruitList = new JList(fruitsName);
        fruitList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        fruitList.setSelectedIndex(0);
        fruitList.setVisibleRowCount(3);

        JScrollPane fruitListScrollPane = new JScrollPane(fruitList);

        // Tạo model
        final DefaultListModel vegName = new DefaultListModel();

        vegName.addElement("Xà lách");
        vegName.addElement("Bắp cải");
        vegName.addElement("Khoai tây");
        vegName.addElement("Cà chua");

        // Tạo list với tùy chọn chỉ cho phép lựa chọn nhiều item / 1 lần
        final JList vegList = new JList(vegName);
        vegList.setSelectionMode(
                ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        vegList.setSelectedIndex(0);
        vegList.setVisibleRowCount(3);

        JScrollPane vegListScrollPane = new JScrollPane(vegList);

        JButton showButton = new JButton("Chọn");

        // Gán sự kiện cho nút hiển thị lựa chọn
        showButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String data = "";
                if (fruitList.getSelectedIndex() != -1) {
                    data = "Hoa quả : " + fruitList.getSelectedValue();
                    statusLabel.setText(data);
                }
                if (vegList.getSelectedIndex() != -1) {
                    data += " || Rau xanh : ";
                    for (Object vegetable : vegList.getSelectedValues()) {
                        data += vegetable + " ";
                    }
                }
                statusLabel.setText(data);
            }
        });

        controlPanel.add(fruitListScrollPane);
        controlPanel.add(vegListScrollPane);
        controlPanel.add(showButton);

        mainFrame.setVisible(true);
    }
}

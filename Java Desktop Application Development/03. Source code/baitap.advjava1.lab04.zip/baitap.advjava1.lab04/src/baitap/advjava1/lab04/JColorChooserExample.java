/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baitap.advjava1.lab04;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author minhvufc
 */
public class JColorChooserExample extends JFrame implements ActionListener {

    JButton btnChoose;
    Container mContainer;

    JColorChooserExample() {
        mContainer = getContentPane();
        mContainer.setLayout(new FlowLayout());

        btnChoose = new JButton("Chọn màu nền");
        btnChoose.addActionListener(this);

        mContainer.add(btnChoose);
    }

    public void actionPerformed(ActionEvent e) {
        Color initialcolor = Color.RED;
        Color color = JColorChooser.showDialog(this, "Chọn một màu", initialcolor);
        mContainer.setBackground(color);
    }

    public static void main(String[] args) {
        JColorChooserExample jColorEx = new JColorChooserExample();
        jColorEx.setTitle("Chọn màu sắc cho nền");
        jColorEx.setSize(400, 300);
        jColorEx.setVisible(true);
        jColorEx.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}

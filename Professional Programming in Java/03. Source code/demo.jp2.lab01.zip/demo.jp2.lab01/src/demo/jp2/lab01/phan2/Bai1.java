/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.lab01.phan2;

import java.util.Scanner;

/**
 *
 * @author minhvufc
 */
public class Bai1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bai1 bai1 = new Bai1();
        bai1.nhapDuLieu();
    }

    public void nhapDuLieu() {
        StringBuilder dsSinhVien = new StringBuilder();
        for (int i = 0; i < 3; i++) {
            System.out.println("Mời nhập sinh viên thứ " + (i + 1));
            Scanner nhap = new Scanner(System.in);
            String str = nhap.nextLine();
            dsSinhVien.append(str + "#");
        }

        System.out.println("Danh sach sinh vien");
        String temp = dsSinhVien.toString();
        String arrSV[] = temp.split("#");
        for (int i = 0; i < arrSV.length; i++) {
            System.out.println((i + 1) + " " + arrSV[i]);
        }
    }
}

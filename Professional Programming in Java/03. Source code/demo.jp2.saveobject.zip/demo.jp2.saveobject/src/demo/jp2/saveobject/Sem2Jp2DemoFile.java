/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.saveobject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author minh.vt1
 */
public class Sem2Jp2DemoFile {

    void start() {
        try {
            // Cach 1:
            FileInputStream inputStr = new FileInputStream("hello.txt");

            // Cach 2:
            File file = new File("/xxx/maria.txt");
            FileInputStream fiStream = new FileInputStream(file);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Sem2Jp2DemoFile.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void ghiDuLieu() {
        String str = "\nNếu trên đường đời tấp nập \nTa vô tình vấp phải cục Đô La";
        /*String str = "\nKhông có việc gì khó\n"
         + "Chỉ sợ tiền không nhiều\n"
         + "Đào núi và lấp biển\n"
         + "Không làm được thì....thuê";*/
        byte bufObj[] = str.getBytes();
        try {
            OutputStream output = new FileOutputStream("cam_doc.txt", true);
            output.write(bufObj);
            output.close();
            System.out.println("Ghi thanh Cong");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    void taoFile() {
        File file = new File("D:\\NetBeansProjects\\demo.jp2.saveobject\\xxx\\maria.txt");
        if (!file.exists()) {
            try {
                //file.mkdir();
                file.createNewFile();
            } catch (IOException ex) {
                Logger.getLogger(Sem2Jp2DemoFile.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        System.out.println("Tao file thanh cong!");
    }

    void ghiDuLieuNhanVien_1RaFile() {
        ArrayList<NhanVien_1> lstNhanVien_1 = new ArrayList<>();

        NhanVien_1 nv1 = new NhanVien_1("Ngọc Trinh", 20);
        NhanVien_1 nv2 = new NhanVien_1("Elly Truong", 23);
        NhanVien_1 nv3 = new NhanVien_1("Thuy Top", 25);

        lstNhanVien_1.add(nv1);
        lstNhanVien_1.add(nv2);
        lstNhanVien_1.add(nv3);
        try {
            FileOutputStream fileOutput = new FileOutputStream("dulieuxxx.txt");
            ObjectOutputStream objOut = new ObjectOutputStream(fileOutput);
            objOut.writeObject(lstNhanVien_1);
            objOut.flush();
            objOut.close();

            System.out.println("Ghi thanh Cong");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    void docDuLieuNhanVien_1TuFile() {
        ArrayList<NhanVien_1> lstNhanVien_1 = new ArrayList<>();

        try {
            FileInputStream fileInput = new FileInputStream("dulieuxxx.txt");
            ObjectInputStream objInput = new ObjectInputStream(fileInput);

            NhanVien_1 nv;
            while ((nv = (NhanVien_1) objInput.readObject()) != null) {
                lstNhanVien_1.add(nv);
            }

            for (int i = 0; i < lstNhanVien_1.size(); i++) {
                NhanVien_1 nhanVien = lstNhanVien_1.get(i);
                nhanVien.toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void createFolder(String path) {
        File folder = new File(path);
        if (folder.exists()) {
            System.out.println("Tồn tại đường dẫn này");
            if (folder.isDirectory()) {
                System.out.println("Tồn tại thư mục này");
            }
        } else {
            // Không tồn tại thì tạo mới
            folder.mkdirs();
            System.out.println("KHÔNG Tồn tại đường dẫn này, đã tạo mới");
        }
    }

    void createFile(String path) {
        File file = new File(path);
        if (file.exists()) {
            System.out.println("Tồn tại file này");           
        } else {
            try {
                // Không tồn tại thì tạo mới
                file.createNewFile();
            } catch (IOException ex) {
                System.out.println("Lỗi tạo file: " + ex.toString());
            }
            System.out.println("KHÔNG Tồn tại file này, đã tạo mới");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Sem2Jp2DemoFile demo = new Sem2Jp2DemoFile();
        demo.createFolder("bkap/slide");
        demo.createFile("bkap/slide/sinhvien.db");

//        demo.ghiDuLieu();
//        demo.taoFile();
//        demo.ghiDuLieuNhanVien_1RaFile();
//        demo.docDuLieuNhanVien_1TuFile();
    }

}

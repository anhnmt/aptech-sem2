/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.lab05.btth2;

/**
 *
 * @author minhvufc
 */
public class Anna implements Runnable {

    Chat m;
    String[] s1 = {"Hi", "How are you ?", "I am also doing fine!"};

    public Anna(Chat m1) {
        this.m = m1;
        new Thread(this, "Question").start();
    }

    public void run() {
        for (int i = 0; i < s1.length; i++) {
            m.Question(s1[i]);
        }
    }
}


import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author minhvufc
 */
public class TestSynchronized {

    Account account = new Account();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestSynchronized test = new TestSynchronized();
        test.test();
    }

    public void test() {
        Withdrawal withdrawal = new Withdrawal(account, "Thread 1");
        Deposit deposit = new Deposit(account, "Thread 2");
        deposit.start();
        withdrawal.start();
    }

    public class Withdrawal extends Thread {

        Account acc;

        public Withdrawal(Account acc, String name) {
            super(name);
            this.acc = acc;
        }

        @Override
        public void run() {
//            synchronized (acc) {
                int amout = 5; // số tiền rút
                for (int i = 0; i < amout; i++) {
                    acc.amount--;
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(TestSynchronized.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    System.out.println(getName() + " - Số tiền có trong TK: " + acc.amount);
                }
//            }
        }

    }

    public class Deposit extends Thread {

        Account acc;

        public Deposit(Account acc, String name) {
            super(name);
            this.acc = acc;
        }

        @Override
        public void run() {
//            synchronized (acc) {
                int amout = 5; // Số tiền nạp
                for (int i = 0; i < amout; i++) {
                    acc.amount++;
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(TestSynchronized.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    System.out.println(getName() + " - Số tiền có trong TK: " + acc.amount);
                }
//            }
        }
    }

    public class Account {

        int amount = 0;
    }

}


import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author minhvufc
 */
public class TestNotification {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestNotification test = new TestNotification();
        test.test();
    }

    public void test() {
        Message mess = new Message();
        Importer importer = new Importer(mess, "Thread 1");
        Notification notification = new Notification(mess, "Thread 2");

        importer.start();
        notification.start();
    }

    public class Importer extends Thread {

        Message mess;

        public Importer(Message mess, String name) {
            super(name);
            this.mess = mess;
        }

        @Override
        public void run() {
            synchronized (mess) {
                while (true) {
                    System.out.println("Mời nhập:");
                    Scanner input = new Scanner(System.in);
                    mess.message = input.nextLine();
                    mess.notify();
                    try {
                        mess.wait();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(TestNotification.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }

    public class Notification extends Thread {

        Message mess;

        public Notification(Message mess, String name) {
            super(name);
            this.mess = mess;
        }

        @Override
        public void run() {
            synchronized (mess) {
                while (true) {
                    System.out.println("Bạn vừa nhập: " + mess.message);
                    mess.notify();
                    try {
                        mess.wait();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(TestNotification.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }

    public class Message {

        String message;
    }

}

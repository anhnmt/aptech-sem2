/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.newfeaturesinfile;

import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 *
 * @author Vu Tuan Minh
 */
public class DeflaterClassDemo {

    public void testDeInflaterDemo() throws Exception {
        System.out.println("Nén dữ liệu");
        // Nén dữ liệu và trả về gói tập tin đã nén dạng byte
        byte data[] = CompressionUtils.compress(input.getBytes("UTF-8"));
        System.out.println("\n----------------------------------\n");
        System.out.println("Giải nén");
        // Giải nén gói tập tin đã nén
        CompressionUtils.decompress(data);
    }

    public void testBasicDeInflater() throws Exception {
        // Encode a String into bytes 
        byte[] bInput = input.getBytes();
        System.out.println("Kích thước chuỗi ban đầu: " + (float) bInput.length);

        byte[] inputObj = input.getBytes("UTF-8");
        // Nén chuỗi thành các byte dữ liệu
        byte[] output = new byte[1024];
        Deflater deflater = new Deflater();
        deflater.setInput(inputObj);
        deflater.finish();
        int compressDataLength = deflater.deflate(output);
        System.out.println("Kích thước chuỗi sau khi nén: " + (float) compressDataLength);
        
        System.out.println("Dữ liệu nén: " + new String(output));

        // Giải nén byte dữ liệu thành chuỗi
        Inflater inflaterObj = new Inflater();
        inflaterObj.setInput(output); // , 0, output.length
        byte[] resultObj = new byte[1024];
        int resultLength = inflaterObj.inflate(resultObj);
        inflaterObj.end();
        // Decode the bytes into a String 
        String strOutput = new String(resultObj, 0, resultLength, "UTF-8");
        System.out.println("Recovered string is: " + strOutput);
    }

    public static void main(String[] args) throws Exception {
        DeflaterClassDemo demo = new DeflaterClassDemo();
        // demo.testBasicDeInflater();
//         demo.testDeInflaterDemo();
         
         byte[] dataCompress = CompressionUtils.compress(demo.input.getBytes());
         CompressionUtils.decompress(dataCompress);
    }
    String input = "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam "
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam"
            + "Cộng Hòa Xã Hội Chủ Nghĩa Việt Nam";
}

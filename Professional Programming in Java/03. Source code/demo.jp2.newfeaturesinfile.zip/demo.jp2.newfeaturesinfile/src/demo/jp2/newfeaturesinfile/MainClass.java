/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.newfeaturesinfile;

import java.io.Console;

/**
 *
 * @author Vu Tuan Minh
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Console console = System.console();
        if (console == null) {
            System.err.println("Hệ thống của bạn không hỗ trợ thiết bị Console");
        } else {
            try {
                String username = console.readLine("Nhập Username: ");
                char[] password = console.readPassword("Nhập Password: ");

                System.out.println("Username" + username);
                System.out.println("Password" + new String(password));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}

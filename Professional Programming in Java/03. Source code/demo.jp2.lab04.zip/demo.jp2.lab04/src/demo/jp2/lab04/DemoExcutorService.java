/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.lab04;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author minhvufc
 */
public class DemoExcutorService {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ExecutorService service = Executors.newFixedThreadPool(2);
        for (int i = 0; i < 5; i++) {
            MyThread mt = new MyThread("Thread-" + (i + 1));
            service.submit(mt);
        }        
    }

}

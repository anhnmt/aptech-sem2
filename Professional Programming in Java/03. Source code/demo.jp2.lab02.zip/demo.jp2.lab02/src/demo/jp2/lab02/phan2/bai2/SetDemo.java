/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.lab02.phan2.bai2;

import static java.lang.reflect.Array.set;
import java.util.Arrays;
import java.util.TreeSet;

/**
 *
 * @author minhvufc
 */
public class SetDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int count[] = {34, 22, 10, 60, 30, 22};
        System.out.println("Original Array: " + Arrays.toString(count));
        
        TreeSet sortedSet = new TreeSet<Integer>();
        for (int i = 0; i < 5; i++) {
            sortedSet.add(count[i]);
        }
        
        System.out.println("The sorted list is:");
        System.out.println(sortedSet);
        
        System.out.println("The First element of the set is: "
                + (Integer) sortedSet.first());
        System.out.println("The last element of the set is: "
                + (Integer) sortedSet.last());
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.lab02.phan1.bai3;

/**
 *
 * @author minhvufc
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        AdvancedComparison<Integer> compInt = new AdvancedComparison<>();
        AdvancedComparison<Float> compFloat = new AdvancedComparison<>();
        AdvancedComparison<String> compString = new AdvancedComparison<>();

        compInt.maximum(9, 3, 6);
        compFloat.maximum(8.5f, 9.3f, 2.6f);
        compString.maximum("Việt Nam", "Trung Quốc", "Hoa Kỳ");
    }

}

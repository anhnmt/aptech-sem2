/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.lab02.phan1.bai3;

/**
 *
 * @author minhvufc
 */
public class AdvancedComparison<T extends Comparable<T>> {

    public void maximum(T a, T b, T c) {
        T max = a;
        if (b.compareTo(a) > 0) {
            max = b;
        }
        if (c.compareTo(b) > 0) {
            max = c;
        }
        System.out.println("Maximum is " + max);
    }
}

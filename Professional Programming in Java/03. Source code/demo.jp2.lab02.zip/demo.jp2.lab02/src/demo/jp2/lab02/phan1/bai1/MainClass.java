/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.jp2.lab02.phan1.bai1;

/**
 *
 * @author minhvufc
 */
public class MainClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MyGenerics<String> stringGenerics = new MyGenerics<String>();
        MyGenerics<Integer> integerGenerics = new MyGenerics<Integer>();

        stringGenerics.setT(new String("Tôi yêu Việt Nam"));
        integerGenerics.setT(new Integer(2015));

        System.out.println("Giá trị tại stringGenerics = " + stringGenerics.getT());
        System.out.println("Giá trị tại integerGenerics = " + integerGenerics.getT());
    }

}
